"""Bounded holdout selection with preprocessing fitted inside each split."""
from __future__ import annotations

import time
import warnings

import numpy as np
from sklearn.dummy import DummyClassifier, DummyRegressor
from sklearn.ensemble import ExtraTreesClassifier, ExtraTreesRegressor, HistGradientBoostingClassifier, HistGradientBoostingRegressor
from sklearn.exceptions import ConvergenceWarning
from sklearn.linear_model import LogisticRegression, Ridge
from sklearn.metrics import balanced_accuracy_score, mean_squared_error
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from threadpoolctl import threadpool_limits

from .preprocessing import TableCleaner, build_preprocessor


_DENSE_CELLS = 2_000_000


def _matrix(cleaner, preprocessor, frame, dense=False):
    result = preprocessor.transform(cleaner.transform(frame))
    if dense:
        if result.shape[0] * result.shape[1] > _DENSE_CELLS:
            raise ValueError("Dense candidate exceeds the matrix cell cap")
        if hasattr(result, "toarray"):
            result = result.toarray()
    return result


def _fit(name, task, frame, labels, feature_types, seed, final=False):
    cleaner = TableCleaner(feature_types).fit(frame)
    preprocessor = build_preprocessor(cleaner, scale_numeric=(name == "linear"))
    matrix = preprocessor.fit_transform(cleaner.transform(frame))
    dense = name == "histogram"
    if dense:
        if matrix.shape[0] * matrix.shape[1] > _DENSE_CELLS:
            raise ValueError("Dense candidate exceeds the matrix cell cap")
        if hasattr(matrix, "toarray"):
            matrix = matrix.toarray()
    classification = task == "classification"
    if not cleaner.retained_columns_ or (classification and len(np.unique(labels)) == 1):
        estimator = DummyClassifier(strategy="prior") if classification else DummyRegressor(strategy="mean")
    elif name == "extra_trees":
        kwargs = dict(n_estimators=96 if final else 40, max_depth=24, n_jobs=1, random_state=seed)
        estimator = ExtraTreesClassifier(class_weight="balanced", **kwargs) if classification else ExtraTreesRegressor(**kwargs)
    elif name == "linear":
        estimator = (LogisticRegression(class_weight="balanced", max_iter=200, random_state=seed)
                     if classification else Ridge(alpha=1.0, solver="lsqr"))
    elif name == "histogram":
        kwargs = dict(max_iter=100 if final else 60, max_leaf_nodes=15, max_depth=8,
                      min_samples_leaf=max(5, min(20, len(frame) // 20)), early_stopping=False,
                      random_state=seed)
        estimator = (HistGradientBoostingClassifier(class_weight="balanced", **kwargs)
                     if classification else HistGradientBoostingRegressor(**kwargs))
    else:
        raise ValueError(f"Unknown supervised candidate {name}")
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", ConvergenceWarning)
        estimator.fit(matrix, labels)
    return cleaner, preprocessor, estimator, dense, matrix.shape[1]


def fit_predict_supervised(task, X_train, y_train=None, X_test=None, feature_types=None,
                           n_clusters=None, time_budget=50, seed=42):
    """Choose using train-only holdout, then refit once on all supplied labels.

    The caller must enforce a process deadline. Checks between candidate fits
    cannot interrupt a running sklearn estimator.
    """
    started = time.monotonic()
    if task not in {"classification", "regression"}:
        raise ValueError("Supervised selection requires classification or regression")
    if y_train is None or X_test is None or len(y_train) != len(X_train) or not len(X_train):
        raise ValueError("Aligned nonempty training data, labels, and test features are required")
    if time_budget <= 0:
        raise ValueError("Model time budget must be positive")
    encoder = None
    if task == "classification":
        encoder = LabelEncoder().fit(np.asarray(y_train))
        target = encoder.transform(np.asarray(y_train))
        _, counts = np.unique(target, return_counts=True)
        rare = len(counts) < 2 or counts.min() < 3 or len(counts) > min(30, len(target) // 5)
    else:
        target = np.asarray(y_train, dtype=float)
        if not np.isfinite(target).all():
            raise ValueError("Regression labels must be finite numbers")
        rare = False
    selected = "extra_trees"
    scores = {}
    errors = {}
    skip = None
    if time_budget < 12:
        skip = "low_time_budget"
    elif len(target) < 60 or rare:
        skip = "tiny_data_or_rare_classes"
    elif len(target) > 100_000 or X_train.shape[1] > 1000:
        skip = "large_input"
    with threadpool_limits(limits=1):
        if skip is None:
            indices = np.arange(len(target))
            if len(indices) > 4000:
                indices, _ = train_test_split(indices, train_size=4000, random_state=seed,
                                              stratify=target if task == "classification" else None)
            try:
                fitting, validation = train_test_split(indices, test_size=0.25, random_state=seed,
                    stratify=target[indices] if task == "classification" else None)
            except ValueError:
                # Downsampling can leave only one example of a rare class.
                skip = "sample_too_small_for_stratification"
        if skip is None:
            best = -np.inf
            for name in ("extra_trees", "linear", "histogram"):
                if time.monotonic() - started > time_budget * 0.4:
                    errors[name] = "selection budget exhausted; reserved remaining time for refit"
                    break
                try:
                    fitted = _fit(name, task, X_train.iloc[fitting], target[fitting], feature_types, seed)
                    cleaner, processor, estimator, dense, _ = fitted
                    prediction = estimator.predict(_matrix(cleaner, processor, X_train.iloc[validation], dense))
                    score = (balanced_accuracy_score(target[validation], prediction) if task == "classification"
                             else -float(np.sqrt(mean_squared_error(target[validation], prediction))))
                    scores[name] = float(score)
                    if score > best + 1e-8:
                        best, selected = score, name
                except (ValueError, MemoryError) as exc:
                    errors[name] = str(exc)
        refit_fallback = None
        try:
            fitted = _fit(selected, task, X_train, target, feature_types, seed, final=True)
        except (ValueError, MemoryError) as exc:
            if selected == "extra_trees":
                raise
            refit_fallback = str(exc)
            selected = "extra_trees"
            fitted = _fit(selected, task, X_train, target, feature_types, seed, final=True)
        cleaner, processor, estimator, dense, width = fitted
        if len(X_test):
            # Dense prediction is batched independently of evaluation row count.
            batch = max(1, _DENSE_CELLS // max(1, width)) if dense else len(X_test)
            predictions = np.concatenate([
                estimator.predict(_matrix(cleaner, processor, X_test.iloc[offset:offset + batch], dense))
                for offset in range(0, len(X_test), batch)
            ])
            if encoder is not None:
                predictions = encoder.inverse_transform(predictions.astype(int))
        else:
            predictions = np.array([], dtype=np.asarray(y_train).dtype)
    return predictions, {
        "model": type(estimator).__name__, "strategy": "auto", "selected_candidate": selected,
        "selection_metric": "balanced_accuracy" if task == "classification" else "negative_rmse",
        "validation_scores": scores, "candidate_errors": errors, "selection_skipped": skip,
        "refit_fallback_reason": refit_fallback, "fallback": False,
        "training_rows": len(X_train), "input_features": X_train.shape[1],
        "retained_features": len(cleaner.retained_columns_), "transformed_features": int(width),
        "dropped_constant_columns": cleaner.constant_columns_, "dropped_duplicate_columns": cleaner.duplicate_columns_,
        "seed": int(seed), "cpu_threads": 1, "time_budget_seconds": float(time_budget),
        "model_seconds": time.monotonic() - started,
    }
