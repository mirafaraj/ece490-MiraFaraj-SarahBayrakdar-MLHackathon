"""Pair identical baseline/candidate cases without averaging incompatible task metrics."""

import argparse
import json
from pathlib import Path
from statistics import mean


def summarize(report):
    pairs = {}
    for row in report["datasets"]:
        pairs.setdefault((row["seed"], row["task"], row["name"]), {})[row["strategy"]] = row
    results = []
    for (seed, task, name), strategies in pairs.items():
        if set(strategies) != {"baseline", "auto"}:
            raise ValueError(f"Missing paired strategy: {seed}/{name}")
        baseline, candidate = strategies["baseline"], strategies["auto"]
        if baseline["data_sha256"] != candidate["data_sha256"]:
            raise ValueError(f"Different input rows: {seed}/{name}")
        valid = baseline["valid"] and candidate["valid"]
        metric = {"classification": "balanced_accuracy", "regression": "rmse",
                  "clustering": "adjusted_rand_index"}[task]
        before = baseline["metrics"].get(metric)
        after = candidate["metrics"].get(metric)
        change = ((before - after) if task == "regression" else (after - before)) if valid else None
        results.append({
            "seed": seed, "partition": baseline["partition"], "task": task, "name": name,
            "valid_pair": bool(valid), "metric": metric, "baseline": before, "auto": after,
            "quality_change": change,
            "relative_rmse_reduction": (1 - after / before) if valid and task == "regression" and before else None,
            "outcome": "invalid" if not valid else "tie" if abs(change) <= 1e-9 else "win" if change > 0 else "loss",
            "baseline_seconds": baseline["wall_seconds"], "auto_seconds": candidate["wall_seconds"],
            "auto_model": candidate.get("run_info", {}).get("model", {}).get("model"),
            "auto_fallback": candidate.get("fallback", False),
        })
    aggregates = []
    for partition in sorted({r["partition"] for r in results}):
        for task in ("classification", "regression", "clustering"):
            rows = [r for r in results if r["partition"] == partition and r["task"] == task]
            if not rows:
                continue
            valid = [r for r in rows if r["valid_pair"]]
            aggregates.append({
                "partition": partition, "task": task, "cases": len(rows),
                "outcomes": {label: sum(r["outcome"] == label for r in rows) for label in ("win", "tie", "loss", "invalid")},
                "mean_quality_change": mean(r["quality_change"] for r in valid) if valid and task != "regression" else None,
                "mean_relative_rmse_reduction": mean(r["relative_rmse_reduction"] for r in valid) if valid and task == "regression" else None,
                "mean_baseline_seconds": mean(r["baseline_seconds"] for r in rows),
                "mean_auto_seconds": mean(r["auto_seconds"] for r in rows),
            })
    return {"notice": "Paired development metrics; no official contest points. Positive quality changes favor auto.",
            "source_sha256": report["config"]["source_sha256"], "aggregates": aggregates, "pairs": results}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("report", type=Path)
    parser.add_argument("--output", type=Path, default=Path("experiments/comparison_summary.json"))
    args = parser.parse_args()
    result = summarize(json.loads(args.report.read_text(encoding="utf-8")))
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    for row in result["aggregates"]:
        print(json.dumps(row))


if __name__ == "__main__":
    main()
